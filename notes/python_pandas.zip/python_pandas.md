# Pandas



[Pandas](http://pandas.pydata.org/) is a python library for data analysis. It adopts the Matlab and R philosophy for organizing 2-dimensional data in a special structure called data frame. In bioinformatics pandas are useful for doing tasks that are usually done with Microsoft Excel. The advantages of pandas are:
-  It is fast. Part of it is implemented in C and has very good performance for tables that have up to millions of rows.
-  Provides an interface that simulates databases. This way we can write short expressions that make complex processes.
   * In terms of Computer Science, we say that pandas is for " [declarative language](https://en.wikipedia.org/wiki/Declarative_programming) ", in contrast to the classic python that offers [control flow](https://en.wikipedia.org/wiki/Control_flow) programming.

* Supported by third-party libraries for visualization, Machine Learning (eg [sci-kit](http://scikit-learn.org/stable/) ) and statistics (eg [statmodels](http://statsmodels.sourceforge.net/) ).

* Provides its own methods for fast plotting and statistical analysis

* Easy and fast input / output in various formats (excel included)



We usually import pandas as follows:



```python
import pandas as pd
```


If it is not installed then you can install it as follows:

```bash
pip install pandas
```

Caution. The `pip` must be in the same location as the python.

Let's import a [CSV](https://en.wikipedia.org/wiki/Comma-separated_values) file:



```python
hs = pd.read_csv('https://ftp.ncbi.nlm.nih.gov/gene/DATA/GENE_INFO/Mammalia/Homo_sapiens.gene_info.gz', sep='\t')
```


`sep='\t'` means that the columns are separated by tabs.



The first lines:



```python
hs.head() 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210404</td>
      <td>-</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>NAT1</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210322</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




The last lines:



```python
hs.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>62011</th>
      <td>741158</td>
      <td>8923215</td>
      <td>trnD</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>62012</th>
      <td>741158</td>
      <td>8923216</td>
      <td>trnP</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>62013</th>
      <td>741158</td>
      <td>8923217</td>
      <td>trnA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>62014</th>
      <td>741158</td>
      <td>8923218</td>
      <td>COX1</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>62015</th>
      <td>741158</td>
      <td>8923219</td>
      <td>16S rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>l-rRNA</td>
      <td>rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




The same can be done with:



```python
hs[:5] # The first 5 lines
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210404</td>
      <td>-</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>NAT1</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210322</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




```python
hs[-5:]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>62011</th>
      <td>741158</td>
      <td>8923215</td>
      <td>trnD</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>62012</th>
      <td>741158</td>
      <td>8923216</td>
      <td>trnP</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>62013</th>
      <td>741158</td>
      <td>8923217</td>
      <td>trnA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>tRNA</td>
      <td>tRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>62014</th>
      <td>741158</td>
      <td>8923218</td>
      <td>COX1</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>protein-coding</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>cytochrome c oxidase subunit I</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
    <tr>
      <th>62015</th>
      <td>741158</td>
      <td>8923219</td>
      <td>16S rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>MT</td>
      <td>-</td>
      <td>l-rRNA</td>
      <td>rRNA</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20200909</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




All columns:



```python
hs.columns
```




    Index(['#tax_id', 'GeneID', 'Symbol', 'LocusTag', 'Synonyms', 'dbXrefs',
           'chromosome', 'map_location', 'description', 'type_of_gene',
           'Symbol_from_nomenclature_authority',
           'Full_name_from_nomenclature_authority', 'Nomenclature_status',
           'Other_designations', 'Modification_date', 'Feature_type'],
          dtype='object')




Or in list:



```python
list(hs.columns.values)
```




    ['#tax_id',
     'GeneID',
     'Symbol',
     'LocusTag',
     'Synonyms',
     'dbXrefs',
     'chromosome',
     'map_location',
     'description',
     'type_of_gene',
     'Symbol_from_nomenclature_authority',
     'Full_name_from_nomenclature_authority',
     'Nomenclature_status',
     'Other_designations',
     'Modification_date',
     'Feature_type']




Nice. Let&#39;s just take three columns:



```python
hs[['Symbol', 'chromosome', 'type_of_gene']][:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>chromosome</th>
      <th>type_of_gene</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A1BG</td>
      <td>19</td>
      <td>protein-coding</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A2M</td>
      <td>12</td>
      <td>protein-coding</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A2MP1</td>
      <td>12</td>
      <td>pseudo</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NAT1</td>
      <td>8</td>
      <td>protein-coding</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NAT2</td>
      <td>8</td>
      <td>protein-coding</td>
    </tr>
  </tbody>
</table>
</div>




Caution! The above is equivalent to:



```python
hs[:5][['Symbol', 'chromosome', 'type_of_gene']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Symbol</th>
      <th>chromosome</th>
      <th>type_of_gene</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A1BG</td>
      <td>19</td>
      <td>protein-coding</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A2M</td>
      <td>12</td>
      <td>protein-coding</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A2MP1</td>
      <td>12</td>
      <td>pseudo</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NAT1</td>
      <td>8</td>
      <td>protein-coding</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NAT2</td>
      <td>8</td>
      <td>protein-coding</td>
    </tr>
  </tbody>
</table>
</div>




How many rows and how many columns does the Data Frame have?



```python
hs.shape
```




    (62016, 16)




### Indexes



A dataframe must have an index. By default the index is the serial number of the rows. You can directly ask for a specific value of an index



```python
hs.iloc[10]
```




    #tax_id                                                                               9606
    GeneID                                                                                  16
    Symbol                                                                               AARS1
    LocusTag                                                                                 -
    Synonyms                                                           AARS|CMT2N|DEE29|EIEE29
    dbXrefs                                    MIM:601065|HGNC:HGNC:20|Ensembl:ENSG00000090861
    chromosome                                                                              16
    map_location                                                                       16q22.1
    description                                                       alanyl-tRNA synthetase 1
    type_of_gene                                                                protein-coding
    Symbol_from_nomenclature_authority                                                   AARS1
    Full_name_from_nomenclature_authority                             alanyl-tRNA synthetase 1
    Nomenclature_status                                                                      O
    Other_designations                       alanine--tRNA ligase, cytoplasmic|alaRS|alanin...
    Modification_date                                                                 20210404
    Feature_type                                                                             -
    New_date                                                               2021-04-04 00:00:00
    Name: 10, dtype: object




```python
hs.iloc[:2]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
      <th>is_pseudo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210404</td>
      <td>-</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




Rows 100, 200 and 400:



```python
hs.iloc[[100, 200, 400]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
      <th>is_pseudo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>100</th>
      <td>9606</td>
      <td>119</td>
      <td>ADD2</td>
      <td>-</td>
      <td>ADDB</td>
      <td>MIM:102681|HGNC:HGNC:244|Ensembl:ENSG00000075340</td>
      <td>2</td>
      <td>2p13.3</td>
      <td>adducin 2</td>
      <td>protein-coding</td>
      <td>ADD2</td>
      <td>adducin 2</td>
      <td>O</td>
      <td>beta-adducin|adducin 2 (beta)|erythrocyte addu...</td>
      <td>20210302</td>
      <td>-</td>
      <td>False</td>
    </tr>
    <tr>
      <th>200</th>
      <td>9606</td>
      <td>240</td>
      <td>ALOX5</td>
      <td>-</td>
      <td>5-LO|5-LOX|5LPG|LOG5</td>
      <td>MIM:152390|HGNC:HGNC:435|Ensembl:ENSG00000012779</td>
      <td>10</td>
      <td>10q11.21</td>
      <td>arachidonate 5-lipoxygenase</td>
      <td>protein-coding</td>
      <td>ALOX5</td>
      <td>arachidonate 5-lipoxygenase</td>
      <td>O</td>
      <td>polyunsaturated fatty acid 5-lipoxygenase|LOX-...</td>
      <td>20210406</td>
      <td>-</td>
      <td>False</td>
    </tr>
    <tr>
      <th>400</th>
      <td>9606</td>
      <td>479</td>
      <td>ATP12A</td>
      <td>-</td>
      <td>ATP1AL1|H-K-ATPase|HK</td>
      <td>MIM:182360|HGNC:HGNC:13816|Ensembl:ENSG0000007...</td>
      <td>13</td>
      <td>13q12.12|13q12.1-q12.3</td>
      <td>ATPase H+/K+ transporting non-gastric alpha2 s...</td>
      <td>protein-coding</td>
      <td>ATP12A</td>
      <td>ATPase H+/K+ transporting non-gastric alpha2 s...</td>
      <td>O</td>
      <td>potassium-transporting ATPase alpha chain 2|AT...</td>
      <td>20210302</td>
      <td>-</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>



## Filtering


By filtering we can request for a specific subset of our data that have a ginven property.  A similar term is query (or querying).

Pandas and numpy (we will see in the next lecture) have a common mechanism for filtering. The interesting thing is that this mechanism is, [influenced](https://github.com/pandas-dev/pandas) by R.

For starters we need to make a list that is the same size as the number of rows in the  DataFrame. This list will only have True or False values. Let's see this in practice:

Suppose we only want the odd lines of a dataframe. 
Initially, we make a list where the odd positions contain the `True` value and the even ones the `False` value:



```python
rows = hs.shape[0]
l = [x%2==1 for x in range(rows)]
```


Now `l` can act as a filter if we pass it to a Data Frame:



```python
hs_filtered = hs[l]
```


```python
hs_filtered.shape # Half lines
```




    (31397, 16)




```python
hs_filtered.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210404</td>
      <td>-</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>NAT1</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>5</th>
      <td>9606</td>
      <td>11</td>
      <td>NATP</td>
      <td>-</td>
      <td>AACP|NATP1</td>
      <td>HGNC:HGNC:15</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase pseudogene</td>
      <td>pseudo</td>
      <td>NATP</td>
      <td>N-acetyltransferase pseudogene</td>
      <td>O</td>
      <td>arylamide acetylase pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>7</th>
      <td>9606</td>
      <td>13</td>
      <td>AADAC</td>
      <td>-</td>
      <td>CES5A1|DAC</td>
      <td>MIM:600338|HGNC:HGNC:17|Ensembl:ENSG00000114771</td>
      <td>3</td>
      <td>3q25.1</td>
      <td>arylacetamide deacetylase</td>
      <td>protein-coding</td>
      <td>AADAC</td>
      <td>arylacetamide deacetylase</td>
      <td>O</td>
      <td>arylacetamide deacetylase|arylacetamide deacet...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9606</td>
      <td>15</td>
      <td>AANAT</td>
      <td>-</td>
      <td>DSPS|SNAT</td>
      <td>MIM:600950|HGNC:HGNC:19|Ensembl:ENSG00000129673</td>
      <td>17</td>
      <td>17q25.1</td>
      <td>aralkylamine N-acetyltransferase</td>
      <td>protein-coding</td>
      <td>AANAT</td>
      <td>aralkylamine N-acetyltransferase</td>
      <td>O</td>
      <td>serotonin N-acetyltransferase|arylalkylamine N...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




We notice that it only has odd indexes.

OK, but how does this help me filter? We can simply do a logical operation with one column and the result is a list of logical values that can be used as a filter! For example. All genes on chromosome 8:



```python
filter_chr_8 = hs['chromosome'] == '8'
```


```python
filter_chr_8[:10] # Print first 10
```




    0    False
    1    False
    2    False
    3     True
    4     True
    5     True
    6    False
    7    False
    8    False
    9    False
    Name: chromosome, dtype: bool




We confirm with:



```python
hs['chromosome'][:10]
```




    0    19
    1    12
    2    12
    3     8
    4     8
    5     8
    6    14
    7     3
    8     2
    9    17
    Name: chromosome, dtype: object




we can now apply this filter:



```python
hs[filter_chr_8][:10] # First 10 genes in chromosome 8
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>NAT1</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210322</td>
      <td>-</td>
    </tr>
    <tr>
      <th>5</th>
      <td>9606</td>
      <td>11</td>
      <td>NATP</td>
      <td>-</td>
      <td>AACP|NATP1</td>
      <td>HGNC:HGNC:15</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase pseudogene</td>
      <td>pseudo</td>
      <td>NATP</td>
      <td>N-acetyltransferase pseudogene</td>
      <td>O</td>
      <td>arylamide acetylase pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>54</th>
      <td>9606</td>
      <td>66</td>
      <td>ACTBP6</td>
      <td>-</td>
      <td>H8-PSI-BETA-AC3</td>
      <td>HGNC:HGNC:139</td>
      <td>8</td>
      <td>8q21.2</td>
      <td>ACTB pseudogene 6</td>
      <td>pseudo</td>
      <td>ACTBP6</td>
      <td>ACTB pseudogene 6</td>
      <td>O</td>
      <td>actin, beta pseudogene 6|actin, gamma 1 pseudo...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>95</th>
      <td>9606</td>
      <td>114</td>
      <td>ADCY8</td>
      <td>-</td>
      <td>AC8|ADCY3|HBAC1</td>
      <td>MIM:103070|HGNC:HGNC:239|Ensembl:ENSG00000155897</td>
      <td>8</td>
      <td>8q24.22</td>
      <td>adenylate cyclase 8</td>
      <td>protein-coding</td>
      <td>ADCY8</td>
      <td>adenylate cyclase 8</td>
      <td>O</td>
      <td>adenylate cyclase type 8|ATP pyrophosphate-lya...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>125</th>
      <td>9606</td>
      <td>148</td>
      <td>ADRA1A</td>
      <td>-</td>
      <td>ADRA1C|ADRA1L1|ALPHA1AAR</td>
      <td>MIM:104221|HGNC:HGNC:277|Ensembl:ENSG00000120907</td>
      <td>8</td>
      <td>8p21.2</td>
      <td>adrenoceptor alpha 1A</td>
      <td>protein-coding</td>
      <td>ADRA1A</td>
      <td>adrenoceptor alpha 1A</td>
      <td>O</td>
      <td>alpha-1A adrenergic receptor|G protein coupled...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>131</th>
      <td>9606</td>
      <td>155</td>
      <td>ADRB3</td>
      <td>-</td>
      <td>BETA3AR</td>
      <td>MIM:109691|HGNC:HGNC:288|Ensembl:ENSG00000188778</td>
      <td>8</td>
      <td>8p11.23</td>
      <td>adrenoceptor beta 3</td>
      <td>protein-coding</td>
      <td>ADRB3</td>
      <td>adrenoceptor beta 3</td>
      <td>O</td>
      <td>beta-3 adrenergic receptor|adrenergic, beta-3-...</td>
      <td>20210322</td>
      <td>-</td>
    </tr>
    <tr>
      <th>237</th>
      <td>9606</td>
      <td>284</td>
      <td>ANGPT1</td>
      <td>-</td>
      <td>AGP1|AGPT|ANG1</td>
      <td>MIM:601667|HGNC:HGNC:484|Ensembl:ENSG00000154188</td>
      <td>8</td>
      <td>8q23.1</td>
      <td>angiopoietin 1</td>
      <td>protein-coding</td>
      <td>ANGPT1</td>
      <td>angiopoietin 1</td>
      <td>O</td>
      <td>angiopoietin-1|ANG-1</td>
      <td>20210406</td>
      <td>-</td>
    </tr>
    <tr>
      <th>238</th>
      <td>9606</td>
      <td>285</td>
      <td>ANGPT2</td>
      <td>-</td>
      <td>AGPT2|ANG2</td>
      <td>MIM:601922|HGNC:HGNC:485|Ensembl:ENSG00000091879</td>
      <td>8</td>
      <td>8p23.1</td>
      <td>angiopoietin 2</td>
      <td>protein-coding</td>
      <td>ANGPT2</td>
      <td>angiopoietin 2</td>
      <td>O</td>
      <td>angiopoietin-2|Tie2-ligand|angiopoietin-2B|ang...</td>
      <td>20210406</td>
      <td>-</td>
    </tr>
    <tr>
      <th>239</th>
      <td>9606</td>
      <td>286</td>
      <td>ANK1</td>
      <td>-</td>
      <td>ANK|SPH1|SPH2</td>
      <td>MIM:612641|HGNC:HGNC:492|Ensembl:ENSG00000029534</td>
      <td>8</td>
      <td>8p11.21</td>
      <td>ankyrin 1</td>
      <td>protein-coding</td>
      <td>ANK1</td>
      <td>ankyrin 1</td>
      <td>O</td>
      <td>ankyrin-1|ANK-1|ankyrin 1, erythrocytic|ankyri...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




If we replace `filter_chr_8` with `hs['chromosome&'] == '8'` (see also cell 35) we will have:



```python
hs[hs['chromosome'] == '8'][:10]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>NAT1</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210322</td>
      <td>-</td>
    </tr>
    <tr>
      <th>5</th>
      <td>9606</td>
      <td>11</td>
      <td>NATP</td>
      <td>-</td>
      <td>AACP|NATP1</td>
      <td>HGNC:HGNC:15</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase pseudogene</td>
      <td>pseudo</td>
      <td>NATP</td>
      <td>N-acetyltransferase pseudogene</td>
      <td>O</td>
      <td>arylamide acetylase pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>54</th>
      <td>9606</td>
      <td>66</td>
      <td>ACTBP6</td>
      <td>-</td>
      <td>H8-PSI-BETA-AC3</td>
      <td>HGNC:HGNC:139</td>
      <td>8</td>
      <td>8q21.2</td>
      <td>ACTB pseudogene 6</td>
      <td>pseudo</td>
      <td>ACTBP6</td>
      <td>ACTB pseudogene 6</td>
      <td>O</td>
      <td>actin, beta pseudogene 6|actin, gamma 1 pseudo...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>95</th>
      <td>9606</td>
      <td>114</td>
      <td>ADCY8</td>
      <td>-</td>
      <td>AC8|ADCY3|HBAC1</td>
      <td>MIM:103070|HGNC:HGNC:239|Ensembl:ENSG00000155897</td>
      <td>8</td>
      <td>8q24.22</td>
      <td>adenylate cyclase 8</td>
      <td>protein-coding</td>
      <td>ADCY8</td>
      <td>adenylate cyclase 8</td>
      <td>O</td>
      <td>adenylate cyclase type 8|ATP pyrophosphate-lya...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>125</th>
      <td>9606</td>
      <td>148</td>
      <td>ADRA1A</td>
      <td>-</td>
      <td>ADRA1C|ADRA1L1|ALPHA1AAR</td>
      <td>MIM:104221|HGNC:HGNC:277|Ensembl:ENSG00000120907</td>
      <td>8</td>
      <td>8p21.2</td>
      <td>adrenoceptor alpha 1A</td>
      <td>protein-coding</td>
      <td>ADRA1A</td>
      <td>adrenoceptor alpha 1A</td>
      <td>O</td>
      <td>alpha-1A adrenergic receptor|G protein coupled...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>131</th>
      <td>9606</td>
      <td>155</td>
      <td>ADRB3</td>
      <td>-</td>
      <td>BETA3AR</td>
      <td>MIM:109691|HGNC:HGNC:288|Ensembl:ENSG00000188778</td>
      <td>8</td>
      <td>8p11.23</td>
      <td>adrenoceptor beta 3</td>
      <td>protein-coding</td>
      <td>ADRB3</td>
      <td>adrenoceptor beta 3</td>
      <td>O</td>
      <td>beta-3 adrenergic receptor|adrenergic, beta-3-...</td>
      <td>20210322</td>
      <td>-</td>
    </tr>
    <tr>
      <th>237</th>
      <td>9606</td>
      <td>284</td>
      <td>ANGPT1</td>
      <td>-</td>
      <td>AGP1|AGPT|ANG1</td>
      <td>MIM:601667|HGNC:HGNC:484|Ensembl:ENSG00000154188</td>
      <td>8</td>
      <td>8q23.1</td>
      <td>angiopoietin 1</td>
      <td>protein-coding</td>
      <td>ANGPT1</td>
      <td>angiopoietin 1</td>
      <td>O</td>
      <td>angiopoietin-1|ANG-1</td>
      <td>20210406</td>
      <td>-</td>
    </tr>
    <tr>
      <th>238</th>
      <td>9606</td>
      <td>285</td>
      <td>ANGPT2</td>
      <td>-</td>
      <td>AGPT2|ANG2</td>
      <td>MIM:601922|HGNC:HGNC:485|Ensembl:ENSG00000091879</td>
      <td>8</td>
      <td>8p23.1</td>
      <td>angiopoietin 2</td>
      <td>protein-coding</td>
      <td>ANGPT2</td>
      <td>angiopoietin 2</td>
      <td>O</td>
      <td>angiopoietin-2|Tie2-ligand|angiopoietin-2B|ang...</td>
      <td>20210406</td>
      <td>-</td>
    </tr>
    <tr>
      <th>239</th>
      <td>9606</td>
      <td>286</td>
      <td>ANK1</td>
      <td>-</td>
      <td>ANK|SPH1|SPH2</td>
      <td>MIM:612641|HGNC:HGNC:492|Ensembl:ENSG00000029534</td>
      <td>8</td>
      <td>8p11.21</td>
      <td>ankyrin 1</td>
      <td>protein-coding</td>
      <td>ANK1</td>
      <td>ankyrin 1</td>
      <td>O</td>
      <td>ankyrin-1|ANK-1|ankyrin 1, erythrocytic|ankyri...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>



Αυτό:

```python
hs[hs['chromosome'] == '8']
```

Αξίζει να το ξαναδούμε. Καταρχήν μπορεί να "ξενίζει" η διπλή αναφορά στο hs και η διπλή χρήση του ```..[..[```. Αλλά αν προσέξουμε μας δίνει ένα πολύ δυνατό και εκφραστικό εργαλείο να ορίζουμε φίλτρα δεδομένων. Επίσης δεν πρέπει να ξεχνάμε ότι ακριβώς τον ίδιο μηχανισμό χρησιμοποιεί η R και η Matlab. Αφού λοιπόν τα φίλτρα είναι πίνακες από λογικές τιμές, μπορούμε να κάνουμε λογικές πράξεις!

Τα γονίδια που ανήκουν στο χρωμόσωμα 8 και είναι pseudo genes:

This:

```python
hs[hs['chromosome'] == '8']
```

is worth examining again. At a first glance, this double reference to `hs` and the dual use of brackets (`..[..[`) might be odd. But if we pay attention it gives us a very powerful and expressive tool to define data filters. We must also not forget that R and Matlab use exactly the same mechanism. So since filters are tables of boolean values, we can do logical operations!

The genes that belong to chromosome 8 and are pseudo genes:



```python
hs[ (hs['chromosome'] == '8') & (hs['type_of_gene'] == 'pseudo') ]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5</th>
      <td>9606</td>
      <td>11</td>
      <td>NATP</td>
      <td>-</td>
      <td>AACP|NATP1</td>
      <td>HGNC:HGNC:15</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase pseudogene</td>
      <td>pseudo</td>
      <td>NATP</td>
      <td>N-acetyltransferase pseudogene</td>
      <td>O</td>
      <td>arylamide acetylase pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>54</th>
      <td>9606</td>
      <td>66</td>
      <td>ACTBP6</td>
      <td>-</td>
      <td>H8-PSI-BETA-AC3</td>
      <td>HGNC:HGNC:139</td>
      <td>8</td>
      <td>8q21.2</td>
      <td>ACTB pseudogene 6</td>
      <td>pseudo</td>
      <td>ACTBP6</td>
      <td>ACTB pseudogene 6</td>
      <td>O</td>
      <td>actin, beta pseudogene 6|actin, gamma 1 pseudo...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>568</th>
      <td>9606</td>
      <td>693</td>
      <td>BTF3P1</td>
      <td>-</td>
      <td>HUMBTFA</td>
      <td>HGNC:HGNC:1129</td>
      <td>8</td>
      <td>8q11.23</td>
      <td>BTF3 pseudogene 1</td>
      <td>pseudo</td>
      <td>BTF3P1</td>
      <td>BTF3 pseudogene 1</td>
      <td>O</td>
      <td>basic transcription factor 3, pseudogene 1|lam...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>1289</th>
      <td>9606</td>
      <td>1587</td>
      <td>ADAM3A</td>
      <td>-</td>
      <td>ADAM3|CYRN1|tMDCI</td>
      <td>HGNC:HGNC:209|Ensembl:ENSG00000197475</td>
      <td>8</td>
      <td>8p11.22</td>
      <td>ADAM metallopeptidase domain 3A (pseudogene)</td>
      <td>pseudo</td>
      <td>ADAM3A</td>
      <td>ADAM metallopeptidase domain 3A (pseudogene)</td>
      <td>O</td>
      <td>a disintegrin and metalloproteinase domain 3a ...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>2019</th>
      <td>9606</td>
      <td>2503</td>
      <td>FTH1P11</td>
      <td>-</td>
      <td>FTHL11</td>
      <td>HGNC:HGNC:3981</td>
      <td>8</td>
      <td>8q21.13</td>
      <td>ferritin heavy chain 1 pseudogene 11</td>
      <td>pseudo</td>
      <td>FTH1P11</td>
      <td>ferritin heavy chain 1 pseudogene 11</td>
      <td>O</td>
      <td>ferritin, heavy polypeptide 1 pseudogene 11|fe...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>58933</th>
      <td>9606</td>
      <td>112268397</td>
      <td>LOC112268397</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>8</td>
      <td>-</td>
      <td>40S ribosomal protein S24-like</td>
      <td>pseudo</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>58934</th>
      <td>9606</td>
      <td>112268399</td>
      <td>LOC112268399</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>8</td>
      <td>-</td>
      <td>putative protein N-methyltransferase FAM86B1</td>
      <td>pseudo</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>59895</th>
      <td>9606</td>
      <td>112935968</td>
      <td>PTMAP15</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:53985</td>
      <td>8</td>
      <td>8q22.3</td>
      <td>prothymosin alpha pseudogene 15</td>
      <td>pseudo</td>
      <td>PTMAP15</td>
      <td>prothymosin alpha pseudogene 15</td>
      <td>O</td>
      <td>-</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>60739</th>
      <td>9606</td>
      <td>115482726</td>
      <td>H2AZP7</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:54440|Ensembl:ENSG00000253156</td>
      <td>8</td>
      <td>8q23.3</td>
      <td>H2A.Z histone pseudogene 7</td>
      <td>pseudo</td>
      <td>H2AZP7</td>
      <td>H2A.Z histone pseudogene 7</td>
      <td>O</td>
      <td>-</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>61434</th>
      <td>9606</td>
      <td>117751737</td>
      <td>HIKESHIP3</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:54904|Ensembl:ENSG00000271081</td>
      <td>8</td>
      <td>8p12</td>
      <td>HIKESHI pseudogene 3</td>
      <td>pseudo</td>
      <td>HIKESHIP3</td>
      <td>HIKESHI pseudogene 3</td>
      <td>O</td>
      <td>-</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
<p>690 rows × 16 columns</p>
</div>





ΠΡΟΣΟΧΗ! Οι παρενθέσεις είναι υποχρεωτικές:



Για μια στιγμή, γιατί δεν χρησιμοποιήσαμε τον αγαπημένο μας τελεστή and και χρησημοποιήσαμε αυτό το ```&``` ; Θυμόμαστε ότι το αποτέλεσμα της and είναι **πάντα** (ακόμα και στη pandas) λογικές τιμές (δηλαδή είτε True είτε False). Ναι αλλά εμείς δεν θέλουμε True ή False θέλουμε λίστες από True ή False. Για να κάνουμε αυτή τη διάκριση χρησιμοποιούμε το ```&```. 

Οι τελεστές που μπορούμε να χρησιμοποιήσουμε είναι:
* ```&``` --> and
* ```|``` --> or
* ```~``` --> not

Για παράδειγμα: Όλα τα γονίδια που ΔΕΝ ανήκουν στο χρωμόσωμα 8 ή 9 και είναι pseudo genes (τυπώνουμε τα πρώτα 5):


CAUTION! Brackets are required:

```python
hs[ (hs['chromosome'] == '8') & (hs['type_of_gene'] == 'pseudo') ]
    ^                       ^   ^                              ^
```

Wait, why didn't we use our favorite operator and use this `&` instead? Remember that the result of `and`, `or` and `not` are **always** (even in pandas) boolean values (ie either `True` or `False`). Yet we do not want this operator to return `True` or `False` we want it to return lists with `True` or `False` values. To make this distinction we define another set of operators:

 The operators we can use are:
-  `&` --> and
-  `|` --> or
-  `~` --> not

For example: All genes that do NOT belong to chromosome 8 or 9 and are pseudo genes (print the first 5):



```python
hs[~((hs['chromosome'] == 8) | (hs['chromosome'] == 9)) & (hs['type_of_gene'] == 'pseudo')][:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>5</th>
      <td>9606</td>
      <td>11</td>
      <td>NATP</td>
      <td>-</td>
      <td>AACP|NATP1</td>
      <td>HGNC:HGNC:15</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase pseudogene</td>
      <td>pseudo</td>
      <td>NATP</td>
      <td>N-acetyltransferase pseudogene</td>
      <td>O</td>
      <td>arylamide acetylase pseudogene</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>51</th>
      <td>9606</td>
      <td>62</td>
      <td>ACTBP2</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:135</td>
      <td>5</td>
      <td>5q14.1</td>
      <td>ACTB pseudogene 2</td>
      <td>pseudo</td>
      <td>ACTBP2</td>
      <td>ACTB pseudogene 2</td>
      <td>O</td>
      <td>actin, beta pseudogene 2</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>52</th>
      <td>9606</td>
      <td>63</td>
      <td>ACTBP3</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:136</td>
      <td>18</td>
      <td>18q21.32</td>
      <td>ACTB pseudogene 3</td>
      <td>pseudo</td>
      <td>ACTBP3</td>
      <td>ACTB pseudogene 3</td>
      <td>O</td>
      <td>actin, beta pseudogene 3</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>53</th>
      <td>9606</td>
      <td>64</td>
      <td>ACTBP4</td>
      <td>-</td>
      <td>-</td>
      <td>HGNC:HGNC:137</td>
      <td>5</td>
      <td>5q31.1</td>
      <td>ACTB pseudogene 4</td>
      <td>pseudo</td>
      <td>ACTBP4</td>
      <td>ACTB pseudogene 4</td>
      <td>O</td>
      <td>actin, beta pseudogene 4</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




There are many pandas functions that return filters (lists with`True`/`False` values). For example:

Check if the values of a column contain a given string:



```python
hs[hs['description'].str.contains('membrane')][:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>243</th>
      <td>9606</td>
      <td>290</td>
      <td>ANPEP</td>
      <td>-</td>
      <td>APN|CD13|GP150|LAP1|P150|PEPN</td>
      <td>MIM:151530|HGNC:HGNC:500|Ensembl:ENSG00000166825</td>
      <td>15</td>
      <td>15q26.1</td>
      <td>alanyl aminopeptidase, membrane</td>
      <td>protein-coding</td>
      <td>ANPEP</td>
      <td>alanyl aminopeptidase, membrane</td>
      <td>O</td>
      <td>aminopeptidase N|AP-M|AP-N|alanyl (membrane) a...</td>
      <td>20210316</td>
      <td>-</td>
    </tr>
    <tr>
      <th>411</th>
      <td>9606</td>
      <td>490</td>
      <td>ATP2B1</td>
      <td>-</td>
      <td>PMCA1|PMCA1kb</td>
      <td>MIM:108731|HGNC:HGNC:814|Ensembl:ENSG00000070961</td>
      <td>12</td>
      <td>12q21.33</td>
      <td>ATPase plasma membrane Ca2+ transporting 1</td>
      <td>protein-coding</td>
      <td>ATP2B1</td>
      <td>ATPase plasma membrane Ca2+ transporting 1</td>
      <td>O</td>
      <td>plasma membrane calcium-transporting ATPase 1|...</td>
      <td>20210327</td>
      <td>-</td>
    </tr>
    <tr>
      <th>412</th>
      <td>9606</td>
      <td>491</td>
      <td>ATP2B2</td>
      <td>-</td>
      <td>PMCA2|PMCA2a|PMCA2i</td>
      <td>MIM:108733|HGNC:HGNC:815|Ensembl:ENSG00000157087</td>
      <td>3</td>
      <td>3p25.3</td>
      <td>ATPase plasma membrane Ca2+ transporting 2</td>
      <td>protein-coding</td>
      <td>ATP2B2</td>
      <td>ATPase plasma membrane Ca2+ transporting 2</td>
      <td>O</td>
      <td>plasma membrane calcium-transporting ATPase 2|...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>413</th>
      <td>9606</td>
      <td>492</td>
      <td>ATP2B3</td>
      <td>-</td>
      <td>CFAP39|CLA2|OPCA|PMCA3|PMCA3a|SCAX1</td>
      <td>MIM:300014|HGNC:HGNC:816|Ensembl:ENSG00000067842</td>
      <td>X</td>
      <td>Xq28</td>
      <td>ATPase plasma membrane Ca2+ transporting 3</td>
      <td>protein-coding</td>
      <td>ATP2B3</td>
      <td>ATPase plasma membrane Ca2+ transporting 3</td>
      <td>O</td>
      <td>plasma membrane calcium-transporting ATPase 3|...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>414</th>
      <td>9606</td>
      <td>493</td>
      <td>ATP2B4</td>
      <td>-</td>
      <td>ATP2B2|MXRA1|PMCA4|PMCA4b|PMCA4x</td>
      <td>MIM:108732|HGNC:HGNC:817|Ensembl:ENSG00000058668</td>
      <td>1</td>
      <td>1q32.1</td>
      <td>ATPase plasma membrane Ca2+ transporting 4</td>
      <td>protein-coding</td>
      <td>ATP2B4</td>
      <td>ATPase plasma membrane Ca2+ transporting 4</td>
      <td>O</td>
      <td>plasma membrane calcium-transporting ATPase 4|...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>




Same as before but case insensitive:



```python
hs[hs['description'].str.contains('membrane', case=False)][:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>243</th>
      <td>9606</td>
      <td>290</td>
      <td>ANPEP</td>
      <td>-</td>
      <td>APN|CD13|GP150|LAP1|P150|PEPN</td>
      <td>MIM:151530|HGNC:HGNC:500|Ensembl:ENSG00000166825</td>
      <td>15</td>
      <td>15q26.1</td>
      <td>alanyl aminopeptidase, membrane</td>
      <td>protein-coding</td>
      <td>ANPEP</td>
      <td>alanyl aminopeptidase, membrane</td>
      <td>O</td>
      <td>aminopeptidase N|AP-M|AP-N|alanyl (membrane) a...</td>
      <td>20210316</td>
      <td>-</td>
    </tr>
    <tr>
      <th>411</th>
      <td>9606</td>
      <td>490</td>
      <td>ATP2B1</td>
      <td>-</td>
      <td>PMCA1|PMCA1kb</td>
      <td>MIM:108731|HGNC:HGNC:814|Ensembl:ENSG00000070961</td>
      <td>12</td>
      <td>12q21.33</td>
      <td>ATPase plasma membrane Ca2+ transporting 1</td>
      <td>protein-coding</td>
      <td>ATP2B1</td>
      <td>ATPase plasma membrane Ca2+ transporting 1</td>
      <td>O</td>
      <td>plasma membrane calcium-transporting ATPase 1|...</td>
      <td>20210327</td>
      <td>-</td>
    </tr>
    <tr>
      <th>412</th>
      <td>9606</td>
      <td>491</td>
      <td>ATP2B2</td>
      <td>-</td>
      <td>PMCA2|PMCA2a|PMCA2i</td>
      <td>MIM:108733|HGNC:HGNC:815|Ensembl:ENSG00000157087</td>
      <td>3</td>
      <td>3p25.3</td>
      <td>ATPase plasma membrane Ca2+ transporting 2</td>
      <td>protein-coding</td>
      <td>ATP2B2</td>
      <td>ATPase plasma membrane Ca2+ transporting 2</td>
      <td>O</td>
      <td>plasma membrane calcium-transporting ATPase 2|...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>413</th>
      <td>9606</td>
      <td>492</td>
      <td>ATP2B3</td>
      <td>-</td>
      <td>CFAP39|CLA2|OPCA|PMCA3|PMCA3a|SCAX1</td>
      <td>MIM:300014|HGNC:HGNC:816|Ensembl:ENSG00000067842</td>
      <td>X</td>
      <td>Xq28</td>
      <td>ATPase plasma membrane Ca2+ transporting 3</td>
      <td>protein-coding</td>
      <td>ATP2B3</td>
      <td>ATPase plasma membrane Ca2+ transporting 3</td>
      <td>O</td>
      <td>plasma membrane calcium-transporting ATPase 3|...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
    <tr>
      <th>414</th>
      <td>9606</td>
      <td>493</td>
      <td>ATP2B4</td>
      <td>-</td>
      <td>ATP2B2|MXRA1|PMCA4|PMCA4b|PMCA4x</td>
      <td>MIM:108732|HGNC:HGNC:817|Ensembl:ENSG00000058668</td>
      <td>1</td>
      <td>1q32.1</td>
      <td>ATPase plasma membrane Ca2+ transporting 4</td>
      <td>protein-coding</td>
      <td>ATP2B4</td>
      <td>ATPase plasma membrane Ca2+ transporting 4</td>
      <td>O</td>
      <td>plasma membrane calcium-transporting ATPase 4|...</td>
      <td>20210302</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
</div>



### Series

Μία στήλη σε pandas ονομάζεται Series. Με τη describe μπορούμε να έχουμε μία καλή εικόνα των τιμών που περιέχει:




### Series

A column in pandas is called a [Series](https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.Series.html). With the `describe` function we can get a good overview of its values:



```python
hs['type_of_gene'].describe()
```




    count              62016
    unique                11
    top       protein-coding
    freq               19696
    Name: type_of_gene, dtype: object




Some of the operations that we can do in a column are:

Find all its unique values:



```python
hs['type_of_gene'].unique()
```




    array(['protein-coding', 'pseudo', 'other', 'unknown', 'ncRNA', 'tRNA',
           'rRNA', 'scRNA', 'snoRNA', 'snRNA', 'biological-region'],
          dtype=object)




Find the number of lines that each unique values has:


```python
hs['type_of_gene'].value_counts()
```




    protein-coding       19696
    ncRNA                17513
    pseudo               16556
    biological-region     4754
    unknown               1383
    other                  840
    tRNA                   595
    snoRNA                 541
    snRNA                   71
    rRNA                    63
    scRNA                    4
    Name: type_of_gene, dtype: int64




### Adding columns

We can create a new Series from another by using the `apply` function. `apply` takes a function and applies it to all lines returning a new Series. You can use this Series as a new column.

For example we notice that the `dbXrefs` column contains many IDs to other databases. We can have one of these codes in a new column:



```python
import re
def create_ensembl(row):
    m = re.search(r'Ensembl:(ENSG\d+)', row['dbXrefs'])
    if not m:
        return pd.NA
    
    return m.group(1)

hs['ENSEMBL'] = hs.apply(create_ensembl, axis=1)
```


```python
hs[:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
      <th>ENSEMBL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
      <td>ENSG00000121410</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210404</td>
      <td>-</td>
      <td>ENSG00000175899</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
      <td>ENSG00000256069</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>NAT1</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
      <td>ENSG00000171428</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210322</td>
      <td>-</td>
      <td>ENSG00000156006</td>
    </tr>
  </tbody>
</table>
</div>




Notice that the last column contains the ENSEMBL ID.

We can add a new column with the map:



```python
hs['is_pseudo'] = hs['type_of_gene'].map(lambda x : x=='pseudo')
```


```python
hs[:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
      <th>is_pseudo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210404</td>
      <td>-</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
      <td>True</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>Mitsos</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210322</td>
      <td>-</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




### NA = Not Available

What is this `pd.NA` ? It is the pandas constant used when a value is not.. available. Pandas has a large collection of functions to manage this value:

For example check is a value in a series is `pd.NA` or not. 



```python
hs['ENSEMBL'].isna().value_counts()
```




    False    35145
    True     26871
    Name: ENSEMBL, dtype: int64




Delete the rows where the ENSEMBL column is `pd.NA`:



```python
hs.dropna(subset=['ENSEMBL'])[:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
      <th>ENSEMBL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
      <td>ENSG00000121410</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210404</td>
      <td>-</td>
      <td>ENSG00000175899</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
      <td>ENSG00000256069</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>Mitsos</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
      <td>ENSG00000171428</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210322</td>
      <td>-</td>
      <td>ENSG00000156006</td>
    </tr>
  </tbody>
</table>
</div>




Replace `pd.NA` with another value:



```python
hs['ENSEMBL'].fillna('Does not exist')
```




    0        ENSG00000121410
    1        ENSG00000175899
    2        ENSG00000256069
    3        ENSG00000171428
    4        ENSG00000156006
                  ...       
    62011     Does not exist
    62012     Does not exist
    62013     Does not exist
    62014     Does not exist
    62015     Does not exist
    Name: ENSEMBL, Length: 62016, dtype: object




### Changing a value

To change a value we need to know the row and the column. To be more precise we need to know the index of the line.



```python
hs.at[3, 'Symbol'] = 'Mitsos'
```


```python
hs[:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
      <th>ENSEMBL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9606</td>
      <td>1</td>
      <td>A1BG</td>
      <td>-</td>
      <td>A1B|ABG|GAB|HYST2477</td>
      <td>MIM:138670|HGNC:HGNC:5|Ensembl:ENSG00000121410</td>
      <td>19</td>
      <td>19q13.43</td>
      <td>alpha-1-B glycoprotein</td>
      <td>protein-coding</td>
      <td>A1BG</td>
      <td>alpha-1-B glycoprotein</td>
      <td>O</td>
      <td>alpha-1B-glycoprotein|HEL-S-163pA|epididymis s...</td>
      <td>20210302</td>
      <td>-</td>
      <td>ENSG00000121410</td>
    </tr>
    <tr>
      <th>1</th>
      <td>9606</td>
      <td>2</td>
      <td>A2M</td>
      <td>-</td>
      <td>A2MD|CPAMD5|FWP007|S863-7</td>
      <td>MIM:103950|HGNC:HGNC:7|Ensembl:ENSG00000175899</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin</td>
      <td>protein-coding</td>
      <td>A2M</td>
      <td>alpha-2-macroglobulin</td>
      <td>O</td>
      <td>alpha-2-macroglobulin|C3 and PZP-like alpha-2-...</td>
      <td>20210404</td>
      <td>-</td>
      <td>ENSG00000175899</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9606</td>
      <td>3</td>
      <td>A2MP1</td>
      <td>-</td>
      <td>A2MP</td>
      <td>HGNC:HGNC:8|Ensembl:ENSG00000256069</td>
      <td>12</td>
      <td>12p13.31</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>pseudo</td>
      <td>A2MP1</td>
      <td>alpha-2-macroglobulin pseudogene 1</td>
      <td>O</td>
      <td>pregnancy-zone protein pseudogene</td>
      <td>20210302</td>
      <td>-</td>
      <td>ENSG00000256069</td>
    </tr>
    <tr>
      <th>3</th>
      <td>9606</td>
      <td>9</td>
      <td>Mitsos</td>
      <td>-</td>
      <td>AAC1|MNAT|NAT-1|NATI</td>
      <td>MIM:108345|HGNC:HGNC:7645|Ensembl:ENSG00000171428</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 1</td>
      <td>protein-coding</td>
      <td>NAT1</td>
      <td>N-acetyltransferase 1</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 1|N-acetyltransf...</td>
      <td>20210302</td>
      <td>-</td>
      <td>ENSG00000171428</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9606</td>
      <td>10</td>
      <td>NAT2</td>
      <td>-</td>
      <td>AAC2|NAT-2|PNAT</td>
      <td>MIM:612182|HGNC:HGNC:7646|Ensembl:ENSG00000156006</td>
      <td>8</td>
      <td>8p22</td>
      <td>N-acetyltransferase 2</td>
      <td>protein-coding</td>
      <td>NAT2</td>
      <td>N-acetyltransferase 2</td>
      <td>O</td>
      <td>arylamine N-acetyltransferase 2|N-acetyltransf...</td>
      <td>20210322</td>
      <td>-</td>
      <td>ENSG00000156006</td>
    </tr>
  </tbody>
</table>
</div>



### Μετονομασία στήλης


### Rename column



```python
hs = hs.rename(columns={'ENSEMBL': 'ENSEMBL genes'})
```

### Διαγραφή στήλης:


### Delete column:



```python
hs = hs.drop('ENSEMBL genes', axis=1)
```

### Ημερομηνίες

Πρατηρούμε ότι η στήλη: ```hs['Modification_date']``` έχει ημερομηνίες αλλά η pandas τα βλέπει σαν string. Μπορούμε να αλλάξουμε τον τύπο μίας στήλης και να δηλώσουμε ότι περιέχει ημερομηνίες. 

Για να το κάνουμε αυτό πρέπει να δηλώσουμε το format της ημερομηνίας: https://docs.python.org/3/library/datetime.html#strftime-and-strptime-behavior


### Dates

 Note that the column: `hs[&#39;Modification_date&#39;]` has dates but pandas sees them as a string. We can change the type of a column and state that it contains dates.

 To do this we must declare the format of the date: [https://docs.python.org/3/library/datetime.html#strftime-and-strptime-behavior](https://docs.python.org/3/library/datetime.html#strftime-and-strptime-behavior)



```python
hs['New_date'] = pd.to_datetime(hs['Modification_date'], format='%Y%m%d')
```

Προσέξτε τη διαφορά


Notice the difference



```python
hs[['New_date', 'Modification_date']][:10]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>New_date</th>
      <th>Modification_date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2021-03-02</td>
      <td>20210302</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2021-04-04</td>
      <td>20210404</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2021-03-02</td>
      <td>20210302</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2021-03-02</td>
      <td>20210302</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2021-03-22</td>
      <td>20210322</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2021-03-02</td>
      <td>20210302</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2021-03-07</td>
      <td>20210307</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2021-03-02</td>
      <td>20210302</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2021-03-02</td>
      <td>20210302</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2021-03-02</td>
      <td>20210302</td>
    </tr>
  </tbody>
</table>
</div>



Τώρα μπορούμε να κάνουμε ταξινόμηση, filtering, κτλ με βάση την ημερομηνία. Ποιο είναι το γονίδιο το οποίο ανανεώθηκε πιο παλιά:


Now we can do sorting, filtering, etc by date. What is the oldest renewed gene:



```python
hs.iloc[hs['New_date'].idxmin()]
```




    #tax_id                                                               9606
    GeneID                                                                7909
    Symbol                                                                HEMC
    LocusTag                                                                 -
    Synonyms                                                               HCI
    dbXrefs                                                         MIM:602089
    chromosome                                                               -
    map_location                                                             -
    description                              hemangioma, capillary, hereditary
    type_of_gene                                                       unknown
    Symbol_from_nomenclature_authority                                       -
    Full_name_from_nomenclature_authority                                    -
    Nomenclature_status                                                      -
    Other_designations                                                       -
    Modification_date                                                 20170402
    Feature_type                                                             -
    New_date                                               2017-04-02 00:00:00
    Name: 6234, dtype: object



### Ταξινόμηση
Χρησημοποιούμε τη sort_values:


### Classification

 We use sort_values:



```python
hs.sort_values('description')[:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>#tax_id</th>
      <th>GeneID</th>
      <th>Symbol</th>
      <th>LocusTag</th>
      <th>Synonyms</th>
      <th>dbXrefs</th>
      <th>chromosome</th>
      <th>map_location</th>
      <th>description</th>
      <th>type_of_gene</th>
      <th>Symbol_from_nomenclature_authority</th>
      <th>Full_name_from_nomenclature_authority</th>
      <th>Nomenclature_status</th>
      <th>Other_designations</th>
      <th>Modification_date</th>
      <th>Feature_type</th>
      <th>New_date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>57645</th>
      <td>9606</td>
      <td>110599572</td>
      <td>LOC110599572</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>10</td>
      <td>-</td>
      <td>-8 kb enhancer of CYP2C8</td>
      <td>biological-region</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>-</td>
      <td>20210302</td>
      <td>regulatory:enhancer</td>
      <td>2021-03-02</td>
    </tr>
    <tr>
      <th>2120</th>
      <td>9606</td>
      <td>2632</td>
      <td>GBE1</td>
      <td>-</td>
      <td>APBD|GBE|GSD4</td>
      <td>MIM:607839|HGNC:HGNC:4180|Ensembl:ENSG00000114480</td>
      <td>3</td>
      <td>3p12.2</td>
      <td>1,4-alpha-glucan branching enzyme 1</td>
      <td>protein-coding</td>
      <td>GBE1</td>
      <td>1,4-alpha-glucan branching enzyme 1</td>
      <td>O</td>
      <td>1,4-alpha-glucan-branching enzyme|amylo-(1,4 t...</td>
      <td>20210302</td>
      <td>-</td>
      <td>2021-03-02</td>
    </tr>
    <tr>
      <th>8277</th>
      <td>9606</td>
      <td>10554</td>
      <td>AGPAT1</td>
      <td>-</td>
      <td>1-AGPAT1|G15|LPAAT-alpha|LPAATA</td>
      <td>MIM:603099|HGNC:HGNC:324|Ensembl:ENSG00000204310</td>
      <td>6</td>
      <td>6p21.32</td>
      <td>1-acylglycerol-3-phosphate O-acyltransferase 1</td>
      <td>protein-coding</td>
      <td>AGPAT1</td>
      <td>1-acylglycerol-3-phosphate O-acyltransferase 1</td>
      <td>O</td>
      <td>1-acyl-sn-glycerol-3-phosphate acyltransferase...</td>
      <td>20210302</td>
      <td>-</td>
      <td>2021-03-02</td>
    </tr>
    <tr>
      <th>8278</th>
      <td>9606</td>
      <td>10555</td>
      <td>AGPAT2</td>
      <td>-</td>
      <td>1-AGPAT2|BSCL|BSCL1|LPAAB|LPAAT-beta</td>
      <td>MIM:603100|HGNC:HGNC:325|Ensembl:ENSG00000169692</td>
      <td>9</td>
      <td>9q34.3</td>
      <td>1-acylglycerol-3-phosphate O-acyltransferase 2</td>
      <td>protein-coding</td>
      <td>AGPAT2</td>
      <td>1-acylglycerol-3-phosphate O-acyltransferase 2</td>
      <td>O</td>
      <td>1-acyl-sn-glycerol-3-phosphate acyltransferase...</td>
      <td>20210302</td>
      <td>-</td>
      <td>2021-03-02</td>
    </tr>
    <tr>
      <th>13332</th>
      <td>9606</td>
      <td>56894</td>
      <td>AGPAT3</td>
      <td>-</td>
      <td>1-AGPAT 3|LPAAT-GAMMA1|LPAAT3</td>
      <td>MIM:614794|HGNC:HGNC:326|Ensembl:ENSG00000160216</td>
      <td>21</td>
      <td>21q22.3</td>
      <td>1-acylglycerol-3-phosphate O-acyltransferase 3</td>
      <td>protein-coding</td>
      <td>AGPAT3</td>
      <td>1-acylglycerol-3-phosphate O-acyltransferase 3</td>
      <td>O</td>
      <td>1-acyl-sn-glycerol-3-phosphate acyltransferase...</td>
      <td>20210302</td>
      <td>-</td>
      <td>2021-03-02</td>
    </tr>
  </tbody>
</table>
</div>



### Από python --> pandas


### From python -&gt; pandas


Αν έχετε μία δομή σε python μπορείτε να τη μετασχηματίσετε ώστε να μπορεί να μπει σαν είσοδο στη DataFrame και να επιστρέψει ένα DataFrame. 

Η DataFrame υποστηρίζει δύο διαφορετικές δομές:

**Δομή 1η:** Λίστα από dictionaries. Κάθε κλειδί στο dictionary είναι το όνομα μίας στήλης:


If you have a structure in python you can transform it so that it can enter the DataFrame and return a DataFrame.

 DataFrame supports two different structures:

 **Structure 1:** List of dictionaries. Each key in the dictionary is the name of a column:



```python
l = [
    {'col_1': 1, 'col_2': 1, 'col_3': 'test_1'},
    {'col_1': 2, 'col_2': 4, 'col_3': 'test_2'},
    {'col_1': 3, 'col_2': 5, 'col_3': 'test_5'},
    {'col_1': 1, 'col_2': 1, 'col_3': 'test_2'},
    {'col_1': 1, 'col_2': 2, 'col_3': 'test_4'},
]

df = pd.DataFrame(l)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>test_1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>4</td>
      <td>test_2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>5</td>
      <td>test_5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>test_2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>2</td>
      <td>test_4</td>
    </tr>
  </tbody>
</table>
</div>



**Δομή 2η**: Dictionaries με λίστες:


**Structure 2** : Dictionaries with lists:



```python
l = {
    'col_1': [1,2,3,1,1],
    'col_2': [1,4,5,1,2],
    'col_3': ['test_1', 'test_2', 'test_5', 'test_2', 'test_4'],
}
df = pd.DataFrame(l)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>test_1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>4</td>
      <td>test_2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>5</td>
      <td>test_5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>test_2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>2</td>
      <td>test_4</td>
    </tr>
  </tbody>
</table>
</div>



### Από pandas --> python

Με τη μέθοδο ```to_dict``` μπορείτε να μετατρέψετε σε dictionary ή λίστα:


### From pandas -&gt; python

 With the `to_dict` method you can convert to dictionary or list:



```python
df.to_dict('records') # Λίστα από dictionaries
```




    [{'col_1': 1, 'col_2': 1, 'col_3': 'test_1'},
     {'col_1': 2, 'col_2': 4, 'col_3': 'test_2'},
     {'col_1': 3, 'col_2': 5, 'col_3': 'test_5'},
     {'col_1': 1, 'col_2': 1, 'col_3': 'test_2'},
     {'col_1': 1, 'col_2': 2, 'col_3': 'test_4'}]




```python
df.to_dict('index') # Dictionaies από dictionaries. Τα κλειδιά είναι τα indexes
```




    {0: {'col_1': 1, 'col_2': 1, 'col_3': 'test_1'},
     1: {'col_1': 2, 'col_2': 4, 'col_3': 'test_2'},
     2: {'col_1': 3, 'col_2': 5, 'col_3': 'test_5'},
     3: {'col_1': 1, 'col_2': 1, 'col_3': 'test_2'},
     4: {'col_1': 1, 'col_2': 2, 'col_3': 'test_4'}}




```python
df.to_dict('dict') # Dictionary από dictionaries. Τα κλειδιά είναι οι στήλες
```




    {'col_1': {0: 1, 1: 2, 2: 3, 3: 1, 4: 1},
     'col_2': {0: 1, 1: 4, 2: 5, 3: 1, 4: 2},
     'col_3': {0: 'test_1', 1: 'test_2', 2: 'test_5', 3: 'test_2', 4: 'test_4'}}




```python
df.to_dict('list') # Dictionary από λίστες. Τα κλειδιά είναι οι στήλες
```




    {'col_1': [1, 2, 3, 1, 1],
     'col_2': [1, 4, 5, 1, 2],
     'col_3': ['test_1', 'test_2', 'test_5', 'test_2', 'test_4']}




```python
pd.DataFrame({0: {'col_1': 1, 'col_2': 1, 'col_3': 'test_1'},
 1: {'col_1': 2, 'col_2': 4, 'col_3': 'test_2'},
 2: {'col_1': 3, 'col_2': 5, 'col_3': 'test_5'},
 3: {'col_1': 1, 'col_2': 1, 'col_3': 'test_2'},
 4: {'col_1': 1, 'col_2': 2, 'col_3': 'test_4'}})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>col_1</th>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>col_2</th>
      <td>1</td>
      <td>4</td>
      <td>5</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>col_3</th>
      <td>test_1</td>
      <td>test_2</td>
      <td>test_5</td>
      <td>test_2</td>
      <td>test_4</td>
    </tr>
  </tbody>
</table>
</div>



### [Σώζοντας ένα pandas](https://wwf.panda.org/discover/knowledge_hub/endangered_species/giant_panda/panda/why_we_save_the_giant_panda/?)  DataFrame


### [Saving a](https://wwf.panda.org/discover/knowledge_hub/endangered_species/giant_panda/panda/why_we_save_the_giant_panda/?) DataFrame pandas


Τα pandas είναι μία "εξωστρεφής" βιβλιοθήκη. Αυτό σημαίνει ότι μπορεί να σώζει και να φορτώνει από/σε πολλά φορμάτ. Το πιο κοινό είναι το csv:


Pandas are an "extroverted" library. This means it can save and load from / to many formats. The most common is csv:



```python
df.to_csv('test.csv')
```


```python
!cat test.csv # Για windows: !type test.csv
```

    ,col_1,col_2,col_3
    0,1,1,test_1
    1,2,4,test_2
    2,3,5,test_5
    3,1,1,test_2
    4,1,2,test_4



```python
df.to_csv('test.csv', index=None) # Σώζουμε χωρίς το index
```


```python
!cat test.csv # Για windows: !type test.csv
```

    col_1,col_2,col_3
    1,1,test_1
    2,4,test_2
    3,5,test_5
    1,1,test_2
    1,2,test_4


Μπορούμε να σώσουμε ένα αρχείο σε φορμάτ excel:


We can save a file in excel format:



```python
df.to_excel('test.xlsx')
```

Και να διαβάσουμε από excel:


And read from excel:



```python
df2 = pd.read_excel('test.xlsx')
```


```python
df2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>test_1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2</td>
      <td>4</td>
      <td>test_2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>test_5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>test_2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>1</td>
      <td>2</td>
      <td>test_4</td>
    </tr>
  </tbody>
</table>
</div>



Διαβάστε εδώ: https://pandas.pydata.org/pandas-docs/stable/user_guide/io.html για τα διαφορετικά φορμάτ που μπορούμε να διαβάσουμε και να γράψουμε.


Read here: [https://pandas.pydata.org/pandas-docs/stable/user_guide/io.html](https://pandas.pydata.org/pandas-docs/stable/user_guide/io.html) for the different formats we can read and write.


### Iteration


### Iteration


Αν και σπάνια το χρειαζόμαστε ([..και προσπαθούμε να αντίσταθούμε στον πειρασμό να το χρησιμοποιήσουμε](https://stackoverflow.com/questions/16476924/how-to-iterate-over-rows-in-a-dataframe-in-pandas)) μπορούμε να κάνουμε iterate (επανάληψη) σε κάθε γραμμή του DataFrame. Αν και υπάρχουν [πολλοί τρόποι](https://stackoverflow.com/questions/16476924/how-to-iterate-over-rows-in-a-dataframe-in-pandas) για να το κάνουμε αυτό, εδω δείχνουμε το itertuples:


Although we rarely need it ( [..and try to resist the temptation to use it](https://stackoverflow.com/questions/16476924/how-to-iterate-over-rows-in-a-dataframe-in-pandas) ) we can iterate on each line of the DataFrame. Although there are [many ways](https://stackoverflow.com/questions/16476924/how-to-iterate-over-rows-in-a-dataframe-in-pandas) to do this, here we show itertuples:



```python
for x in df2.itertuples():
    print ('Index: ', x.Index, 'col_2', x.col_2)
```

    Index:  0 col_2 1
    Index:  1 col_2 4
    Index:  2 col_2 5
    Index:  3 col_2 1
    Index:  4 col_2 2


### Grouping

[Το grouping](https://en.wikipedia.org/wiki/Grouped_data) είναι μία από τις πιο βασικές λειτουργίες των βιβλιοθηκών που χειρίζονται 2-διάστατα δεδομένα. Στην ουσία με το grouping χωρίζουμε τις γραμμές σε groups. Από κάθε group παίρνουμε κάποιες στήλες και σε όλες τις τιμές του group της κάθε στήλης εφαρμόζουμε μία συνάρτηση. Με αυτόν τον τρόπο μπορούμε να κάνουμε πολύ χρήσιμες ερωτήσεις όπως: "για κάθε χρωμόσωμα ποιο είναι το μεγαλύτερο γονίδιο;", "για κάθε νομό ποια είναι η μεγαλύτερη πόλη", "ποιος είναι ο μέσος όρος των γονιδίων που έχουν συσχετιστεί με τον καρκίνο για κάθε χρωμόσωμα;" κτλ.. 

Η pandas έχει μία βασική δομή για το grouping:

```text

df.groupby( [ ... ] )[ [...] ].aggregate( ... )
               |         |                 |
               |         |                 > Συνάρτηση που θα εφαρμόσουμε σε κάθε group-αρισμένη στήλη
               |         > Στήλες που θα group-αριστούν
               > Στήλες που περιέχουν τις τιμές με βάση τις οποίες θα γίνει το  grouping. 
               > Κάθε διαφορετική τιμή τους θα είναι και ένα group          

```

Ας δούμε μερικά παραδείγματα. Φτιάχνουμε ένα random dataframe με 3 στήλες 20 γραμμές και τιμές από 1-4:


### Grouping

 [Grouping](https://en.wikipedia.org/wiki/Grouped_data) is one of the most basic functions of libraries that handle 2-dimensional data. In essence, with grouping we divide the lines into groups. We take some columns from each group and we apply a function to all the group values of each column. In this way we can ask very useful questions such as: "for each chromosome what is the largest gene?", "For each county what is the largest city", "what is the average of the genes associated with cancer for each chromosome? " etc ..

 Pandas have a basic structure for grouping:

 Let&#39;s look at some examples. We make a random dataframe with 3 columns 20 rows and values from 1-4:



```python
import random

d = {
    'col_1': [random.randint(1,4) for x in range(20)],
    'col_2': [random.randint(1,4) for x in range(20)],
    'col_3': [random.randint(1,4) for x in range(20)],
}
df = pd.DataFrame(d)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_1</th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1</td>
      <td>4</td>
      <td>2</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>8</th>
      <td>4</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>4</td>
      <td>4</td>
      <td>2</td>
    </tr>
    <tr>
      <th>10</th>
      <td>4</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2</td>
      <td>4</td>
      <td>2</td>
    </tr>
    <tr>
      <th>13</th>
      <td>1</td>
      <td>2</td>
      <td>4</td>
    </tr>
    <tr>
      <th>14</th>
      <td>4</td>
      <td>3</td>
      <td>2</td>
    </tr>
    <tr>
      <th>15</th>
      <td>2</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>16</th>
      <td>3</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1</td>
      <td>2</td>
      <td>4</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1</td>
      <td>2</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



Για κάθε διαφορετική τιμή της στήλης col_1, ποια είναι η μικρότερη τιμή της col_2; 


For each different value of the col_1 column, what is the smallest value of col_2?



```python
df.groupby(['col_1'])[['col_2']].aggregate('min')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_2</th>
    </tr>
    <tr>
      <th>col_1</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>



Για κάθε διαφορετική τιμή της στήλης ```col_1```, ποια είναι η μικρότερη και μεγαλύτερη τιμή της ```col_2```; 


For each different value of the `col_1` column, what is the smallest and largest value of `col_2` ?



```python
df.groupby(['col_1'])[['col_2']].aggregate(['min', 'max'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="2" halign="left">col_2</th>
    </tr>
    <tr>
      <th></th>
      <th>min</th>
      <th>max</th>
    </tr>
    <tr>
      <th>col_1</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>4</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>



Για κάθε διαφορετική τιμή της στήλης ```col_1```, ποια είναι η μικρότερη τιμή της στήλης ```col_2``` και μεγαλύτερη τιμή της στήλης ```col_3```; 


For each different value in column `col_1` , what is the smallest value in column `col_2` and the largest value in column `col_3` ?



```python
df.groupby(['col_1'])[['col_2', 'col_3']].aggregate({'col_2': 'min', 'col_3': 'max'})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>col_2</th>
      <th>col_3</th>
    </tr>
    <tr>
      <th>col_1</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>



Για κάθε διαφορετική τιμή της στήλης ```col_1```, ποια είναι η μικρότερη και μεγαλύτερη τιμή της στήλης ```col_2``` και μικρότερη και μεγαλύτερη τιμή της στήλης ```col_3```; 


For each different value of the `col_1` column, what is the smallest and largest value of the `col_2` column and the smallest and largest value of the `col_3` column?



```python
df.groupby(['col_1'])[['col_2', 'col_3']].aggregate( ['min', 'max'] )
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="2" halign="left">col_2</th>
      <th colspan="2" halign="left">col_3</th>
    </tr>
    <tr>
      <th></th>
      <th>min</th>
      <th>max</th>
      <th>min</th>
      <th>max</th>
    </tr>
    <tr>
      <th>col_1</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>4</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>4</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>4</td>
      <td>1</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>



Ένα group μπορεί να έχει παραπάνω από μία στήλες. Σε αυτή τη περίπτωση κάθε group περιέχει όλες τις διαφορετικές τιμές που προκύπτουν από τους συνδυασμούς των διαφορετικών τιμών των 2 (ή παραπάνω) στηλών.

Για όλες τις διαφορετικές τιμές της στήλης ```col_1``` και ```col_2``` ποια είναι η μικρότερη τιμή της στήλης ```col_3```;


A group can have more than one column. In this case each group contains all the different values resulting from the combinations of the different values of the 2 (or more) columns.

 For all the different values in column `col_1` and `col_2` what is the smallest value in column `col_3` ?



```python
df.groupby(['col_1', 'col_2'])[['col_3']].aggregate('min')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>col_3</th>
    </tr>
    <tr>
      <th>col_1</th>
      <th>col_2</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="4" valign="top">1</th>
      <th>1</th>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">2</th>
      <th>2</th>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <th>4</th>
      <td>3</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">4</th>
      <th>3</th>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



Σαν aggregate functions μπορείτε να βάλετε [[πηγή](https://cmdlinetips.com/2019/10/pandas-groupby-13-functions-to-aggregate/)]: 


* ```mean()```: Compute mean of groups
* ```sum()```: Compute sum of group values
* ```size()```: Compute group sizes
* ```count()```: Compute count of group
* ```std()```: Standard deviation of groups
* ```var()```: Compute variance of groups
* ```sem()```: Standard error of the mean of groups
* ```describe()```: Generates descriptive statistics
* ```first()```: Compute first of group values
* ```last()```: Compute last of group values
* ```nth()``` : Take nth value, or a subset if n is a list
* ```min()```: Compute min of group values
* ```max()```: Compute max of group values




As aggregate functions you can put [ [source](https://cmdlinetips.com/2019/10/pandas-groupby-13-functions-to-aggregate/) ]:
-  `mean()` : Compute mean of groups
-  `sum()` : Compute sum of group values
-  `size()` : Compute group sizes
-  `count()` : Compute count of group
-  `std()` : Standard deviation of groups
-  `var()` : Compute variance of groups
-  `sem()` : Standard error of the mean of groups
-  `describe()` : Generates descriptive statistics
-  `first()` : Compute first of group values
-  `last()` : Compute last of group values
-  `nth()` : Take nth value, or a subset if n is a list
-  `min()` : Compute min of group values
-  `max()` : Compute max of group values


Ας δούμε μερικά παραδείγματα από τα "δικά μας" δεδομένα. 

Πόσα γονίδια έχει κάθε χρωμόσωμα;


Let&#39;s look at some examples from "our" data.

 How many genes does each chromosome have?



```python
hs.groupby('chromosome')[['GeneID']].aggregate('count')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GeneID</th>
    </tr>
    <tr>
      <th>chromosome</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>-</th>
      <td>146</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5826</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2463</td>
    </tr>
    <tr>
      <th>10|19|3</th>
      <td>1</td>
    </tr>
    <tr>
      <th>11</th>
      <td>3302</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2826</td>
    </tr>
    <tr>
      <th>13</th>
      <td>1557</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2290</td>
    </tr>
    <tr>
      <th>15</th>
      <td>2098</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2255</td>
    </tr>
    <tr>
      <th>17</th>
      <td>2812</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1122</td>
    </tr>
    <tr>
      <th>19</th>
      <td>2825</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4471</td>
    </tr>
    <tr>
      <th>20</th>
      <td>1521</td>
    </tr>
    <tr>
      <th>21</th>
      <td>885</td>
    </tr>
    <tr>
      <th>22</th>
      <td>1409</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3470</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2743</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2943</td>
    </tr>
    <tr>
      <th>6</th>
      <td>3478</td>
    </tr>
    <tr>
      <th>7</th>
      <td>3200</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2470</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2581</td>
    </tr>
    <tr>
      <th>MT</th>
      <td>110</td>
    </tr>
    <tr>
      <th>Un</th>
      <td>66</td>
    </tr>
    <tr>
      <th>X</th>
      <td>2492</td>
    </tr>
    <tr>
      <th>X|Y</th>
      <td>66</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>588</td>
    </tr>
  </tbody>
</table>
</div>



Για κάθε ένα από τα χρωμοσώματα X και Y, πόσα διαφορετικά γονίδια υπάρχουν;


For each of the X and Y chromosomes, how many different genes are there?



```python
hs[hs['chromosome'].isin(['X', 'Y'])].groupby(['chromosome', 'type_of_gene'])[['GeneID']].aggregate('count')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>GeneID</th>
    </tr>
    <tr>
      <th>chromosome</th>
      <th>type_of_gene</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="8" valign="top">X</th>
      <th>biological-region</th>
      <td>157</td>
    </tr>
    <tr>
      <th>ncRNA</th>
      <td>442</td>
    </tr>
    <tr>
      <th>other</th>
      <td>10</td>
    </tr>
    <tr>
      <th>protein-coding</th>
      <td>830</td>
    </tr>
    <tr>
      <th>pseudo</th>
      <td>906</td>
    </tr>
    <tr>
      <th>snoRNA</th>
      <td>16</td>
    </tr>
    <tr>
      <th>tRNA</th>
      <td>5</td>
    </tr>
    <tr>
      <th>unknown</th>
      <td>126</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">Y</th>
      <th>biological-region</th>
      <td>11</td>
    </tr>
    <tr>
      <th>ncRNA</th>
      <td>107</td>
    </tr>
    <tr>
      <th>other</th>
      <td>29</td>
    </tr>
    <tr>
      <th>protein-coding</th>
      <td>46</td>
    </tr>
    <tr>
      <th>pseudo</th>
      <td>389</td>
    </tr>
    <tr>
      <th>unknown</th>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>



Ας αλλάξουμε τη σειρά των στηλών στο grouping:


Let&#39;s change the order of the columns in the grouping:



```python
hs2 = hs[hs['chromosome'].isin(['X', 'Y'])].groupby(['type_of_gene', 'chromosome'])[['GeneID']].aggregate('count')
hs2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>GeneID</th>
    </tr>
    <tr>
      <th>type_of_gene</th>
      <th>chromosome</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="2" valign="top">biological-region</th>
      <th>X</th>
      <td>157</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>11</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">ncRNA</th>
      <th>X</th>
      <td>442</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>107</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">other</th>
      <th>X</th>
      <td>10</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>29</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">protein-coding</th>
      <th>X</th>
      <td>830</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>46</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">pseudo</th>
      <th>X</th>
      <td>906</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>389</td>
    </tr>
    <tr>
      <th>snoRNA</th>
      <th>X</th>
      <td>16</td>
    </tr>
    <tr>
      <th>tRNA</th>
      <th>X</th>
      <td>5</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">unknown</th>
      <th>X</th>
      <td>126</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>



Κάτι αρκετά εξεζητημένο είναι ότι μπορούμε να εφαρμόσουμε μία συνάρτηση σε κάθε group με την apply. Για παράδειγμα Για κάθε type_of_gene ποιο είναι το ποσοσότ που ανήκει στο χρωμόσωμα X και ποιο το αντίστοιχο για το χρωμόσωμα Y;


Something quite sophisticated is that we can apply a function to any group with apply. For example For each type_of_gene what is the percentage belonging to the X chromosome and what corresponds to the Y chromosome?



```python
hs2.groupby(level=0).apply(lambda x: 100 * x / float(x.sum()))
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>GeneID</th>
    </tr>
    <tr>
      <th>type_of_gene</th>
      <th>chromosome</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="2" valign="top">biological-region</th>
      <th>X</th>
      <td>93.452381</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>6.547619</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">ncRNA</th>
      <th>X</th>
      <td>80.510018</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>19.489982</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">other</th>
      <th>X</th>
      <td>25.641026</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>74.358974</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">protein-coding</th>
      <th>X</th>
      <td>94.748858</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>5.251142</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">pseudo</th>
      <th>X</th>
      <td>69.961390</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>30.038610</td>
    </tr>
    <tr>
      <th>snoRNA</th>
      <th>X</th>
      <td>100.000000</td>
    </tr>
    <tr>
      <th>tRNA</th>
      <th>X</th>
      <td>100.000000</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">unknown</th>
      <th>X</th>
      <td>95.454545</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>4.545455</td>
    </tr>
  </tbody>
</table>
</div>



Το level σημαίνει σε ποιο "group" (από τα δύο που έχουμε εφαρμόσουμε) να γίνει το apply. Η αλήθεια είναι οτι αφού το X έχει πολύ περισσότερα γονίδια από το Y ο παραπάνω πίνακας δεν μας λέει και πάρα πολλά. Ας κάνουμε apply με τη function στο δεύτερο level:


The level means in which "group" (of the two we have applied) to apply. The truth is that since X has many more genes than Y the above table does not tell us too much. Let&#39;s apply with the function in the second level:



```python
hs3 = hs2.groupby(level=1).apply(lambda x: 100 * x / float(x.sum()))
hs3
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>GeneID</th>
    </tr>
    <tr>
      <th>type_of_gene</th>
      <th>chromosome</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="2" valign="top">biological-region</th>
      <th>X</th>
      <td>6.300161</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>1.870748</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">ncRNA</th>
      <th>X</th>
      <td>17.736758</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>18.197279</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">other</th>
      <th>X</th>
      <td>0.401284</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>4.931973</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">protein-coding</th>
      <th>X</th>
      <td>33.306581</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>7.823129</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">pseudo</th>
      <th>X</th>
      <td>36.356340</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>66.156463</td>
    </tr>
    <tr>
      <th>snoRNA</th>
      <th>X</th>
      <td>0.642055</td>
    </tr>
    <tr>
      <th>tRNA</th>
      <th>X</th>
      <td>0.200642</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">unknown</th>
      <th>X</th>
      <td>5.056180</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>1.020408</td>
    </tr>
  </tbody>
</table>
</div>



Ενδιαφέρον: Στο χρωμόσωμα X το 33.3% των γονίδιων που περιέχει είναι protein-coding. Το αντίστοιχο ποσοστό για το Y είναι 7.8%. Ενώ για το Y το 66.2% των γονιδίων είναι pseudo και για το Χ είναι 36.3%. Μάλλον δεν κάνει και πολλά πράγματα το Y..


Interesting: On the X chromosome 33.3% of the genes it contains are protein-coding. The corresponding percentage for Y is 7.8%. While for Y 66.2% of the genes are pseudo and for X it is 36.3%. Y .. probably does not do many things ..


Μπορούμε να του πούμε: Το πρώτο group κάντο στήλες:


We can tell him: The first group make columns:



```python
hs3.unstack(0)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="8" halign="left">GeneID</th>
    </tr>
    <tr>
      <th>type_of_gene</th>
      <th>biological-region</th>
      <th>ncRNA</th>
      <th>other</th>
      <th>protein-coding</th>
      <th>pseudo</th>
      <th>snoRNA</th>
      <th>tRNA</th>
      <th>unknown</th>
    </tr>
    <tr>
      <th>chromosome</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>X</th>
      <td>6.300161</td>
      <td>17.736758</td>
      <td>0.401284</td>
      <td>33.306581</td>
      <td>36.356340</td>
      <td>0.642055</td>
      <td>0.200642</td>
      <td>5.056180</td>
    </tr>
    <tr>
      <th>Y</th>
      <td>1.870748</td>
      <td>18.197279</td>
      <td>4.931973</td>
      <td>7.823129</td>
      <td>66.156463</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.020408</td>
    </tr>
  </tbody>
</table>
</div>



Ή το 2ο group κάντο στήλες:


Or the 2nd group make columns:



```python
hs3.unstack(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="2" halign="left">GeneID</th>
    </tr>
    <tr>
      <th>chromosome</th>
      <th>X</th>
      <th>Y</th>
    </tr>
    <tr>
      <th>type_of_gene</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>biological-region</th>
      <td>6.300161</td>
      <td>1.870748</td>
    </tr>
    <tr>
      <th>ncRNA</th>
      <td>17.736758</td>
      <td>18.197279</td>
    </tr>
    <tr>
      <th>other</th>
      <td>0.401284</td>
      <td>4.931973</td>
    </tr>
    <tr>
      <th>protein-coding</th>
      <td>33.306581</td>
      <td>7.823129</td>
    </tr>
    <tr>
      <th>pseudo</th>
      <td>36.356340</td>
      <td>66.156463</td>
    </tr>
    <tr>
      <th>snoRNA</th>
      <td>0.642055</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>tRNA</th>
      <td>0.200642</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>unknown</th>
      <td>5.056180</td>
      <td>1.020408</td>
    </tr>
  </tbody>
</table>
</div>



Το unstacking είναι σημαντικό γιατί μας επιτρέπει να κάνουμε τα groups μπάρες (δες και συνέχεια)


Unstacking is important because it allows us to make groups bars (see also below)



```python
hs3.unstack(1).plot(kind='bar')
```




    <AxesSubplot:xlabel='type_of_gene'>




    
![png](output_179_1.png)
    


Εδώ βλέπουμε πως κάναμε μία "επεξεργασία" των δεδομένων χωρίς να κάνουμε ούτε μία for, if, κτλ.. Αυτός είναι ο "[δηλωτικός τρόπος προγραμματισμού](https://en.wikipedia.org/wiki/Declarative_programming)". Συνιθίζεται όταν γράφουμε πολλές εντολές που κάνουν διαδοχικές επεξεργασίες να τις γράφουμε με αυτό το στυλ (method chaining):


Here we see that we did a "processing" of the data without doing any for, if, etc .. This is the " [declarative way of programming](https://en.wikipedia.org/wiki/Declarative_programming) ". It is common when writing many commands that do sequential processing to write them in this style (method chaining):



```python
(hs[hs['chromosome'].isin(['X', 'Y'])]
 .groupby(['type_of_gene', 'chromosome'])[['GeneID']]
 .aggregate('count')
 .groupby(level=1)
 .apply(lambda x: 100 * x / float(x.sum()))
 .unstack(1)
 .plot(kind='bar')
)
```




    <AxesSubplot:xlabel='type_of_gene'>




    
![png](output_182_1.png)
    


### Plotting 

Η pandas υποστηρίζει ένα μεγάλο πλήθος από plots. Σε μελλοντικό μάθημα θα ασχοληθούμε περισσότερο με το πως κάνουμε plots χωρίς της pandas.

Barplots: πλήθος απο γονίδια ανά χρωμόσωμα:


### Plotting

 Pandas support a large number of plots. In a future lesson we will deal more with how to make plots without pandas.

 Barplots: number of genes per chromosome:



```python
hs['chromosome'].value_counts().plot(kind='bar')
```




    <AxesSubplot:>




    
![png](output_185_1.png)
    


Το ίδιο σε piechart. **ΠΡΟΣΟΧΗ!!** Αποφεύγουμε να χρησιμοποιούμε piechart σε επιστημονικές δημοσιεύσεις! Google: ```why are pie charts bad```


The same in piechart. **CAUTION!!** Avoid using piechart in scientific publications! Google: `why are pie charts bad`



```python
hs['chromosome'].value_counts().plot(kind='pie')
```




    <AxesSubplot:ylabel='chromosome'>




    
![png](output_188_1.png)
    


# Ένα παράδειγμα με GWAS


# An example with GWAS


Ας χρησιμοποιήσουμε έναν κατάλογο από [GWA studies](https://en.wikipedia.org/wiki/Genome-wide_association_study). O κατάλογος βρίσκεται σε αυτό το link: https://www.ebi.ac.uk/gwas/api/search/downloads/full για να το φορτώσετε τρέξτε (κάνει πολύ ώρα!):


Let&#39;s use a list from [GWA studies](https://en.wikipedia.org/wiki/Genome-wide_association_study) . The directory is at this link: [https://www.ebi.ac.uk/gwas/api/search/downloads/full](https://www.ebi.ac.uk/gwas/api/search/downloads/full) to load it run (it takes a long time!):



```python
gwas = pd.read_csv('https://www.ebi.ac.uk/gwas/api/search/downloads/full', sep='\t')
```

    /Users/admin/anaconda3/lib/python3.8/site-packages/IPython/core/interactiveshell.py:3146: DtypeWarning: Columns (9,11,12,23,27) have mixed types.Specify dtype option on import or set low_memory=False.
      has_raised = await self.run_ast_nodes(code_ast.body, cell_name,


Οι στήλες:


The columns:



```python
gwas.columns
```




    Index(['DATE ADDED TO CATALOG', 'PUBMEDID', 'FIRST AUTHOR', 'DATE', 'JOURNAL',
           'LINK', 'STUDY', 'DISEASE/TRAIT', 'INITIAL SAMPLE SIZE',
           'REPLICATION SAMPLE SIZE', 'REGION', 'CHR_ID', 'CHR_POS',
           'REPORTED GENE(S)', 'MAPPED_GENE', 'UPSTREAM_GENE_ID',
           'DOWNSTREAM_GENE_ID', 'SNP_GENE_IDS', 'UPSTREAM_GENE_DISTANCE',
           'DOWNSTREAM_GENE_DISTANCE', 'STRONGEST SNP-RISK ALLELE', 'SNPS',
           'MERGED', 'SNP_ID_CURRENT', 'CONTEXT', 'INTERGENIC',
           'RISK ALLELE FREQUENCY', 'P-VALUE', 'PVALUE_MLOG', 'P-VALUE (TEXT)',
           'OR or BETA', '95% CI (TEXT)', 'PLATFORM [SNPS PASSING QC]', 'CNV'],
          dtype='object')



Ποια είναι τα 10 γονίδια στα οποία έχουν γίνει τα περισσότερα GWAS;


What are the 10 genes in which most GWAS have been made?



```python
gwas["MAPPED_GENE"].value_counts()[:10].plot(kind="bar")
```




    <AxesSubplot:>




    
![png](output_199_1.png)
    


Μετατροπή του DATE από string σε datetime


Convert DATE from string to datetime



```python
gwas['DATE'] = pd.to_datetime(gwas["DATE"]) # Μετατροπή του DATE από string σε datetime
```

Ας δούμε μερικά χαρακτηριστικά της στήλης P-VALUE ;


Let&#39;s look at some features of the P-VALUE column?



```python
gwas['PVALUE_MLOG'].describe()
```




    count    251401.000000
    mean         17.671208
    std          66.731631
    min           5.000000
    25%           7.000000
    50%           9.301030
    75%          14.698970
    max       22135.221849
    Name: PVALUE_MLOG, dtype: float64



Ας τη κάνουμε plot με βάση τον χρόνο:


Let&#39;s plot it based on time:



```python
gwas.plot(x='DATE', y='PVALUE_MLOG')
```




    <AxesSubplot:xlabel='DATE'>




    
![png](output_208_1.png)
    



```python
gwas[gwas['PVALUE_MLOG']<1000].plot(x='DATE', y='PVALUE_MLOG')
```




    <AxesSubplot:xlabel='DATE'>




    
![png](output_209_1.png)
    


Πόσα gwas δημοσιεύονται κάθε χρόνο;


How many gwas are published each year?



```python
gwas.groupby(gwas['DATE'].dt.year)['DATE'].count().plot(kind='bar')
```




    <AxesSubplot:xlabel='DATE'>




    
![png](output_212_1.png)
    


Ένας άλλος τρόπος να τα πλοτάρουμε:


Another way to plot them:



```python
gwas.groupby(gwas['DATE'].dt.year)['DATE'].count().plot()
```




    <AxesSubplot:xlabel='DATE'>




    
![png](output_215_1.png)
    


Ας πάρουμε όλα τα GWAS που έχουν γίνει σε ασθένειες ή φαινότυπους που έχουν μέσα τη λέξη "Breast", και τα SNPs που έχουν βρεθεί έχουν συσχετιστεί με p-value<10<sup>-10</sup>, και ας τα κατατάξουμε σε χρωμοσώματα:


Let&#39;s take all the GWAS that have been done on diseases or phenotypes that have the word "Breast" in them, and the SNPs that have been found have been associated with p-value &lt;10 &lt;sup&gt; -10 &lt;/sup&gt;, and let&#39;s rank them chromosomes:



```python
(
    gwas[ (gwas["DISEASE/TRAIT"].str.contains('Breast')) & (gwas["PVALUE_MLOG"]>10)]
    .groupby("CHR_ID")['CHR_ID']
    .aggregate('count').plot(kind='bar')
)
```




    <AxesSubplot:xlabel='CHR_ID'>




    
![png](output_218_1.png)
    


Λογικό ότι το χρωμόσωμα 5 που έχει το BRCA2 gene είναι #1


It makes sense that chromosome 5 on the BRCA2 gene is # 1


Ποιος είναι ο ερευνητής που έχει τις περισσότερες δημοσιεύσεις στο Nature Genetics;


Who is the researcher with the most publications in Nature Genetics?



```python
(
    gwas[gwas['JOURNAL'] == 'Nat Genet']
    .groupby('FIRST AUTHOR')
    .aggregate('count')['PUBMEDID']
    .idxmax()
)
```




    'Lee JJ'



Ποιο region περιέχει τις περισσότερες μελέτες σχετικά με καρκίνο;


Which region contains the most cancer studies?



```python
(
    gwas[gwas['DISEASE/TRAIT'].str.contains('cancer', case=False, na=False)]
    .groupby('REGION')
    .aggregate('count')['PUBMEDID']
    .idxmax()
)
```




    '8q24.21'



Ποιος είναι ο μέσος όρος και το median του allele_frequency για όλα τα variants που ανακαλύπτοντε κάθε χρόνο;


What is the average and median of allele_frequency for all the variants you discover each year?



```python
gwas['RISK ALLELE FREQUENCY']=pd.to_numeric(gwas['RISK ALLELE FREQUENCY'], errors='coerce')

gwas_2 = ( 
 gwas
 .groupby(gwas_2['DATE'].dt.year)['RISK ALLELE FREQUENCY']
 .aggregate(['mean', 'median'])
)
gwas_2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mean</th>
      <th>median</th>
    </tr>
    <tr>
      <th>DATE</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2005.0</th>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2006.0</th>
      <td>0.370000</td>
      <td>0.370000</td>
    </tr>
    <tr>
      <th>2007.0</th>
      <td>0.415373</td>
      <td>0.400000</td>
    </tr>
    <tr>
      <th>2008.0</th>
      <td>0.389350</td>
      <td>0.350000</td>
    </tr>
    <tr>
      <th>2009.0</th>
      <td>0.362769</td>
      <td>0.320000</td>
    </tr>
    <tr>
      <th>2010.0</th>
      <td>0.358266</td>
      <td>0.330000</td>
    </tr>
    <tr>
      <th>2011.0</th>
      <td>0.384316</td>
      <td>0.340000</td>
    </tr>
    <tr>
      <th>2012.0</th>
      <td>0.340888</td>
      <td>0.300000</td>
    </tr>
    <tr>
      <th>2013.0</th>
      <td>0.414986</td>
      <td>0.380000</td>
    </tr>
    <tr>
      <th>2014.0</th>
      <td>0.420903</td>
      <td>0.390000</td>
    </tr>
    <tr>
      <th>2015.0</th>
      <td>0.498522</td>
      <td>0.477000</td>
    </tr>
    <tr>
      <th>2016.0</th>
      <td>0.367788</td>
      <td>0.338245</td>
    </tr>
    <tr>
      <th>2017.0</th>
      <td>0.382940</td>
      <td>0.335076</td>
    </tr>
    <tr>
      <th>2018.0</th>
      <td>0.473471</td>
      <td>0.474000</td>
    </tr>
    <tr>
      <th>2019.0</th>
      <td>0.403819</td>
      <td>0.381000</td>
    </tr>
    <tr>
      <th>2020.0</th>
      <td>0.438670</td>
      <td>0.416900</td>
    </tr>
    <tr>
      <th>2021.0</th>
      <td>0.385103</td>
      <td>0.359920</td>
    </tr>
  </tbody>
</table>
</div>



Ας κάνουμε ένα scatter plot με τον x να είναι το YEAR και το y να είναι τα mean και median


Let&#39;s make a scatter plot with x being the YEAR and y being the mean and median



```python
gwas_2.plot(style='.')
```




    <AxesSubplot:xlabel='DATE'>




    
![png](output_232_1.png)
    


Και ένα scatter plot με το χ να είναι το mean και το y το median:


And a scatter plot with x being the mean and y being the median:



```python
gwas_2.plot.scatter(x='mean', y='median')
```




    <AxesSubplot:xlabel='mean', ylabel='median'>




    
![png](output_235_1.png)
    


### Περισσότερα

* [Cheatsheet](https://pandas.pydata.org/Pandas_Cheat_Sheet.pdf)
* [Introduction to Pandas](https://realpython.com/pandas-dataframe/) . [plotting with pandas](https://realpython.com/pandas-plot-python/)
* [100 pandas puzzles](https://github.com/ajcr/100-pandas-puzzles)


### More
-  [Cheatsheet](https://pandas.pydata.org/Pandas_Cheat_Sheet.pdf)
-  [Introduction to Pandas](https://realpython.com/pandas-dataframe/) . [plotting with pandas](https://realpython.com/pandas-plot-python/)
-  [100 pandas puzzles](https://github.com/ajcr/100-pandas-puzzles)



```python

```
